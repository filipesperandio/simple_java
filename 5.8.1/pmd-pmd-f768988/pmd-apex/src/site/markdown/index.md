# PMD Apex

Contains the PMD implementation to support the Apex programming language.

Please note, that this module requires a Java 8 runtime environment.
