/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */

package net.sourceforge.pmd.lang.dfa;

import net.sourceforge.pmd.lang.ast.Node;

public interface DFAGraphMethod extends Node {

    String getName();
}
